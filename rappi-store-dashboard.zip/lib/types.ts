export interface DataRow {
  plotName: string
  metric: string
  timestamp: string
  value: number
}

export interface ProcessedData {
  data: DataRow[]
  files: number
  totalRows: number
}

export interface StatsData {
  maxStores: number
  minStores: number
  avgStores: number
  maxTimestamp: string
  minTimestamp: string
  totalRecords: number
  timeRange: string
  volatility: number
}

export interface ChatMessage {
  role: "user" | "assistant"
  content: string
}
