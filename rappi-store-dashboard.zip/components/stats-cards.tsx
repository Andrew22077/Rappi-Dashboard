"use client"

import { Store, TrendingUp, TrendingDown, Activity, Clock, BarChart3 } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import type { StatsData } from "@/lib/types"

interface StatsCardsProps {
  stats: StatsData
}

const statItems = [
  {
    key: "maxStores" as const,
    label: "Maximo de Tiendas",
    icon: TrendingUp,
    color: "text-emerald-600",
    bg: "bg-emerald-50",
    format: (v: number) => v.toLocaleString(),
  },
  {
    key: "minStores" as const,
    label: "Minimo de Tiendas",
    icon: TrendingDown,
    color: "text-red-500",
    bg: "bg-red-50",
    format: (v: number) => v.toLocaleString(),
  },
  {
    key: "avgStores" as const,
    label: "Promedio de Tiendas",
    icon: Store,
    color: "text-primary",
    bg: "bg-accent",
    format: (v: number) => v.toLocaleString(),
  },
  {
    key: "totalRecords" as const,
    label: "Total Registros",
    icon: BarChart3,
    color: "text-blue-600",
    bg: "bg-blue-50",
    format: (v: number) => v.toLocaleString(),
  },
  {
    key: "volatility" as const,
    label: "Volatilidad",
    icon: Activity,
    color: "text-amber-600",
    bg: "bg-amber-50",
    format: (v: number) => v.toFixed(1) + "%",
  },
  {
    key: "timeRange" as const,
    label: "Rango de Tiempo",
    icon: Clock,
    color: "text-indigo-600",
    bg: "bg-indigo-50",
    format: (v: string) => v,
  },
]

export function StatsCards({ stats }: StatsCardsProps) {
  return (
    <div className="grid grid-cols-2 gap-4 lg:grid-cols-3 xl:grid-cols-6">
      {statItems.map((item) => {
        const Icon = item.icon
        const rawValue = stats[item.key]
        const displayValue =
          typeof rawValue === "number"
            ? (item.format as (v: number) => string)(rawValue)
            : (item.format as (v: string) => string)(rawValue as string)

        return (
          <Card key={item.key} className="border-0 shadow-md transition-shadow hover:shadow-lg">
            <CardContent className="flex flex-col gap-3 p-5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  {item.label}
                </span>
                <div className={`flex h-8 w-8 items-center justify-center rounded-lg ${item.bg}`}>
                  <Icon className={`h-4 w-4 ${item.color}`} />
                </div>
              </div>
              <p className="text-2xl font-bold text-foreground">{displayValue}</p>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
