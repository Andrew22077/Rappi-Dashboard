"use client"

import { useState, useRef, useEffect, useMemo } from "react"
import { useChat } from "@ai-sdk/react"
import { DefaultChatTransport } from "ai"
import { MessageCircle, Send, X, Loader2, Bot, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { DataRow, StatsData } from "@/lib/types"

function getMessageText(parts: Array<{ type: string; text?: string }>): string {
  return parts
    .filter((p): p is { type: "text"; text: string } => p.type === "text")
    .map((p) => p.text)
    .join("")
}

interface ChatbotProps {
  data: DataRow[]
  stats: StatsData
}

export function Chatbot({ data, stats }: ChatbotProps) {
  const [open, setOpen] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const [input, setInput] = useState("")

  const dataContext = useMemo(() => {
    const hourMap: Record<number, { total: number; count: number }> = {}
    const sampleSize = Math.min(data.length, 1000)
    const step = Math.max(1, Math.floor(data.length / sampleSize))
    const sampled = data.filter((_, i) => i % step === 0)

    sampled.forEach((d) => {
      const h = new Date(d.timestamp).getHours()
      if (!hourMap[h]) hourMap[h] = { total: 0, count: 0 }
      hourMap[h].total += d.value
      hourMap[h].count++
    })

    const hourAvgs = Object.entries(hourMap)
      .map(([h, v]) => ({ hour: parseInt(h), avg: Math.round(v.total / v.count) }))
      .sort((a, b) => b.avg - a.avg)

    const firstQuarter = sampled.slice(0, Math.floor(sampled.length / 4))
    const lastQuarter = sampled.slice(-Math.floor(sampled.length / 4))
    const firstAvg = Math.round(firstQuarter.reduce((s, d) => s + d.value, 0) / firstQuarter.length)
    const lastAvg = Math.round(lastQuarter.reduce((s, d) => s + d.value, 0) / lastQuarter.length)

    return `Resumen estadistico del dataset de disponibilidad de tiendas Rappi:
- Total de registros: ${stats.totalRecords.toLocaleString()}
- Periodo cubierto: ${stats.timeRange}
- Maximo de tiendas visibles: ${stats.maxStores.toLocaleString()} (en ${stats.maxTimestamp})
- Minimo de tiendas visibles: ${stats.minStores.toLocaleString()} (en ${stats.minTimestamp})
- Promedio: ${stats.avgStores.toLocaleString()} tiendas
- Volatilidad: ${stats.volatility.toFixed(1)}%
- Tendencia: Promedio primer cuarto=${firstAvg}, ultimo cuarto=${lastAvg} (cambio: ${(((lastAvg - firstAvg) / firstAvg) * 100).toFixed(1)}%)
- Top 3 horas con mas tiendas: ${hourAvgs.slice(0, 3).map((h) => `${h.hour}:00 (${h.avg} avg)`).join(", ")}
- Top 3 horas con menos tiendas: ${hourAvgs.slice(-3).reverse().map((h) => `${h.hour}:00 (${h.avg} avg)`).join(", ")}
- Frecuencia de muestreo: ~10 segundos
- Ejemplo de datos recientes (ultimos 10 registros): ${JSON.stringify(data.slice(-10).map((d) => ({ ts: d.timestamp, val: d.value })))}`
  }, [data, stats])

  const { messages, sendMessage, status } = useChat({
    transport: new DefaultChatTransport({
      api: "/api/chat",
      prepareSendMessagesRequest: ({ id, messages }) => ({
        body: { id, messages, dataContext },
      }),
    }),
  })

  const isLoading = status === "streaming" || status === "submitted"

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  useEffect(() => {
    if (open) inputRef.current?.focus()
  }, [open])

  const handleSend = () => {
    if (!input.trim() || isLoading) return
    sendMessage({ text: input })
    setInput("")
  }

  const handleQuickAction = (action: string) => {
    if (isLoading) return
    sendMessage({ text: action })
  }

  const quickActions = [
    "Dame un resumen completo",
    "Cual es el maximo?",
    "Analiza la tendencia",
    "Cuales son los horarios pico?",
  ]

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setOpen(!open)}
        className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-primary shadow-lg transition-all hover:scale-105 hover:shadow-xl"
        aria-label={open ? "Cerrar chat" : "Abrir chat"}
      >
        {open ? (
          <X className="h-6 w-6 text-primary-foreground" />
        ) : (
          <MessageCircle className="h-6 w-6 text-primary-foreground" />
        )}
      </button>

      {/* Chat panel */}
      {open && (
        <div className="fixed bottom-24 right-6 z-50 flex h-[520px] w-[400px] flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-2xl">
          {/* Header */}
          <div className="flex items-center gap-3 bg-primary px-5 py-4">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary-foreground/20">
              <Bot className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h3 className="font-semibold text-primary-foreground">
                Rappi Data Assistant
              </h3>
              <p className="text-xs text-primary-foreground/70">
                Powered by AI
              </p>
            </div>
            <div className="ml-auto flex items-center gap-1.5">
              <span className={`h-2 w-2 rounded-full ${isLoading ? "animate-pulse bg-yellow-300" : "bg-green-400"}`} />
              <span className="text-xs text-primary-foreground/70">
                {isLoading ? "Pensando..." : "Online"}
              </span>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto px-4 py-4">
            <div className="flex flex-col gap-3">
              {/* Welcome message if no messages */}
              {messages.length === 0 && (
                <div className="flex gap-2">
                  <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-secondary">
                    <Bot className="h-3.5 w-3.5 text-foreground" />
                  </div>
                  <div className="max-w-[280px] rounded-2xl bg-secondary px-4 py-2.5 text-sm leading-relaxed text-foreground">
                    Hola! Soy el asistente de datos de Rappi. Tengo acceso a{" "}
                    <strong>{stats.totalRecords.toLocaleString()}</strong> registros de
                    disponibilidad de tiendas. Preguntame lo que necesites saber.
                  </div>
                </div>
              )}

              {messages.map((msg) => {
                const text = getMessageText(msg.parts as Array<{ type: string; text?: string }>)
                if (!text) return null

                return (
                  <div
                    key={msg.id}
                    className={`flex gap-2 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}
                  >
                    <div
                      className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full ${
                        msg.role === "user" ? "bg-primary" : "bg-secondary"
                      }`}
                    >
                      {msg.role === "user" ? (
                        <User className="h-3.5 w-3.5 text-primary-foreground" />
                      ) : (
                        <Bot className="h-3.5 w-3.5 text-foreground" />
                      )}
                    </div>
                    <div
                      className={`max-w-[280px] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                        msg.role === "user"
                          ? "bg-primary text-primary-foreground"
                          : "bg-secondary text-foreground"
                      }`}
                    >
                      {text.split("\n").map((line, j) => (
                        <p key={j} className={j > 0 ? "mt-1" : ""}>
                          {line.split(/\*\*(.*?)\*\*/g).map((part, k) =>
                            k % 2 === 1 ? (
                              <strong key={k}>{part}</strong>
                            ) : (
                              <span key={k}>{part}</span>
                            )
                          )}
                        </p>
                      ))}
                    </div>
                  </div>
                )
              })}

              {isLoading && messages.length > 0 && messages[messages.length - 1].role === "user" && (
                <div className="flex gap-2">
                  <div className="flex h-7 w-7 items-center justify-center rounded-full bg-secondary">
                    <Bot className="h-3.5 w-3.5 text-foreground" />
                  </div>
                  <div className="flex items-center gap-1.5 rounded-2xl bg-secondary px-4 py-2.5">
                    <Loader2 className="h-4 w-4 animate-spin text-primary" />
                    <span className="text-sm text-muted-foreground">Analizando datos...</span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </div>

          {/* Quick actions */}
          {messages.length === 0 && (
            <div className="flex flex-wrap gap-1.5 px-4 pb-2">
              {quickActions.map((action) => (
                <button
                  key={action}
                  onClick={() => handleQuickAction(action)}
                  disabled={isLoading}
                  className="rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium text-foreground transition-colors hover:bg-accent hover:text-accent-foreground disabled:opacity-50"
                >
                  {action}
                </button>
              ))}
            </div>
          )}

          {/* Input */}
          <div className="flex items-center gap-2 border-t border-border bg-card px-4 py-3">
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              placeholder="Escribe tu pregunta..."
              className="flex-1 rounded-xl border border-border bg-secondary px-4 py-2.5 text-sm text-foreground outline-none placeholder:text-muted-foreground focus:border-primary focus:ring-1 focus:ring-primary"
              disabled={isLoading}
            />
            <Button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              size="sm"
              className="h-10 w-10 rounded-xl bg-primary p-0 text-primary-foreground hover:bg-primary/90"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </>
  )
}
