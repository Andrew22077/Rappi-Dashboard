"use client"

import { useCallback, useState } from "react"
import { Upload, FileText, CheckCircle, Loader2 } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"

interface FileUploadProps {
  onUploadComplete: () => void
}

export function FileUpload({ onUploadComplete }: FileUploadProps) {
  const [files, setFiles] = useState<File[]>([])
  const [uploading, setUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [status, setStatus] = useState<"idle" | "uploading" | "processing" | "done">("idle")
  const [dragActive, setDragActive] = useState(false)

  const handleFiles = useCallback((fileList: FileList) => {
    const csvFiles = Array.from(fileList).filter(
      (f) => f.name.endsWith(".csv") || f.type === "text/csv"
    )
    setFiles((prev) => [...prev, ...csvFiles])
  }, [])

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setDragActive(false)
      if (e.dataTransfer.files) handleFiles(e.dataTransfer.files)
    },
    [handleFiles]
  )

  const handleUpload = async () => {
    if (files.length === 0) return

    setUploading(true)
    setStatus("uploading")
    setProgress(10)

    const formData = new FormData()
    files.forEach((f) => formData.append("files", f))

    try {
      setProgress(30)
      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      })

      if (!res.ok) throw new Error("Upload failed")

      setProgress(60)
      setStatus("processing")

      // Small delay so user sees the processing step
      await new Promise((r) => setTimeout(r, 800))
      setProgress(90)

      await new Promise((r) => setTimeout(r, 400))
      setProgress(100)
      setStatus("done")

      setTimeout(() => onUploadComplete(), 600)
    } catch (err) {
      console.error(err)
      setStatus("idle")
    } finally {
      setUploading(false)
    }
  }

  const removeFile = (idx: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== idx))
  }

  return (
    <div className="flex min-h-[80vh] items-center justify-center px-4">
      <Card className="w-full max-w-xl border-0 shadow-2xl">
        <CardContent className="p-8">
          <div className="mb-6 flex flex-col items-center gap-2">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary">
              <Upload className="h-7 w-7 text-primary-foreground" />
            </div>
            <h2 className="text-2xl font-bold text-foreground">Subir Datos</h2>
            <p className="text-center text-sm text-muted-foreground">
              Sube tus archivos CSV con datos de disponibilidad de tiendas
            </p>
          </div>

          {status === "done" ? (
            <div className="flex flex-col items-center gap-4 py-8">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100">
                <CheckCircle className="h-8 w-8 text-emerald-600" />
              </div>
              <p className="text-lg font-semibold text-foreground">
                Archivos procesados correctamente
              </p>
              <p className="text-sm text-muted-foreground">
                Cargando dashboard...
              </p>
            </div>
          ) : (
            <>
              <div
                onDragOver={(e) => {
                  e.preventDefault()
                  setDragActive(true)
                }}
                onDragLeave={() => setDragActive(false)}
                onDrop={handleDrop}
                className={`mb-4 flex cursor-pointer flex-col items-center gap-3 rounded-xl border-2 border-dashed p-8 transition-all ${
                  dragActive
                    ? "border-primary bg-accent"
                    : "border-border hover:border-primary/50 hover:bg-accent/50"
                }`}
                onClick={() => {
                  const input = document.createElement("input")
                  input.type = "file"
                  input.accept = ".csv"
                  input.multiple = true
                  input.onchange = (e) => {
                    const target = e.target as HTMLInputElement
                    if (target.files) handleFiles(target.files)
                  }
                  input.click()
                }}
              >
                <Upload className="h-10 w-10 text-muted-foreground" />
                <div className="text-center">
                  <p className="font-medium text-foreground">
                    Arrastra archivos CSV aqui
                  </p>
                  <p className="text-sm text-muted-foreground">
                    o haz clic para seleccionar
                  </p>
                </div>
              </div>

              {files.length > 0 && (
                <div className="mb-4 flex flex-col gap-2">
                  {files.map((file, idx) => (
                    <div
                      key={`${file.name}-${idx}`}
                      className="flex items-center justify-between rounded-lg bg-secondary px-4 py-2.5"
                    >
                      <div className="flex items-center gap-3">
                        <FileText className="h-4 w-4 text-primary" />
                        <span className="text-sm font-medium text-foreground">
                          {file.name}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {(file.size / 1024).toFixed(1)} KB
                        </span>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          removeFile(idx)
                        }}
                        className="text-sm text-muted-foreground hover:text-destructive"
                      >
                        Quitar
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {(status === "uploading" || status === "processing") && (
                <div className="mb-4 flex flex-col gap-2">
                  <div className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin text-primary" />
                    <span className="text-sm font-medium text-foreground">
                      {status === "uploading"
                        ? "Subiendo archivos..."
                        : "Procesando datos..."}
                    </span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>
              )}

              <Button
                onClick={handleUpload}
                disabled={files.length === 0 || uploading}
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                size="lg"
              >
                {uploading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Procesando...
                  </>
                ) : (
                  <>
                    <Upload className="mr-2 h-4 w-4" />
                    Subir y Procesar ({files.length}{" "}
                    {files.length === 1 ? "archivo" : "archivos"})
                  </>
                )}
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
