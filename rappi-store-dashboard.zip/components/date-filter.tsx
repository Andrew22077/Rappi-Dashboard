"use client"

import { useMemo } from "react"
import { Calendar, RotateCcw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import type { DataRow } from "@/lib/types"

interface DateFilterProps {
  data: DataRow[]
  dateRange: [string, string] | null
  onDateRangeChange: (range: [string, string] | null) => void
}

export function DateFilter({ data, dateRange, onDateRangeChange }: DateFilterProps) {
  const timeInfo = useMemo(() => {
    if (data.length === 0) return null
    const timestamps = data.map((d) => new Date(d.timestamp).getTime())
    const minTime = Math.min(...timestamps)
    const maxTime = Math.max(...timestamps)
    const totalMinutes = Math.round((maxTime - minTime) / 60000)
    return { minTime, maxTime, totalMinutes, minISO: new Date(minTime).toISOString(), maxISO: new Date(maxTime).toISOString() }
  }, [data])

  if (!timeInfo) return null

  const presets = [
    { label: "Todo", value: "all" },
    { label: "Primeros 5 min", value: "first5" },
    { label: "Primeros 10 min", value: "first10" },
    { label: "Ultimos 5 min", value: "last5" },
    { label: "Ultimos 10 min", value: "last10" },
    { label: "Primera mitad", value: "firsthalf" },
    { label: "Segunda mitad", value: "secondhalf" },
  ]

  const handlePreset = (preset: string) => {
    if (preset === "all") {
      onDateRangeChange(null)
      return
    }
    const mid = timeInfo.minTime + (timeInfo.maxTime - timeInfo.minTime) / 2
    let start: number, end: number

    switch (preset) {
      case "first5":
        start = timeInfo.minTime
        end = timeInfo.minTime + 5 * 60000
        break
      case "first10":
        start = timeInfo.minTime
        end = timeInfo.minTime + 10 * 60000
        break
      case "last5":
        start = timeInfo.maxTime - 5 * 60000
        end = timeInfo.maxTime
        break
      case "last10":
        start = timeInfo.maxTime - 10 * 60000
        end = timeInfo.maxTime
        break
      case "firsthalf":
        start = timeInfo.minTime
        end = mid
        break
      case "secondhalf":
        start = mid
        end = timeInfo.maxTime
        break
      default:
        return
    }

    onDateRangeChange([new Date(start).toISOString(), new Date(end).toISOString()])
  }

  const currentLabel = dateRange
    ? `${new Date(dateRange[0]).toLocaleTimeString("es-CO", { hour: "2-digit", minute: "2-digit" })} - ${new Date(dateRange[1]).toLocaleTimeString("es-CO", { hour: "2-digit", minute: "2-digit" })}`
    : "Todos los datos"

  return (
    <Card className="border-0 shadow-md">
      <CardContent className="flex flex-wrap items-center gap-4 p-4">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-accent">
            <Calendar className="h-4 w-4 text-primary" />
          </div>
          <div>
            <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Rango</p>
            <p className="text-sm font-semibold text-foreground">{currentLabel}</p>
          </div>
        </div>

        <div className="flex flex-1 items-center gap-2">
          <Select onValueChange={handlePreset}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Seleccionar rango" />
            </SelectTrigger>
            <SelectContent>
              {presets.map((p) => (
                <SelectItem key={p.value} value={p.value}>
                  {p.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {dateRange && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => onDateRangeChange(null)}
              className="gap-1.5"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Reset
            </Button>
          )}
        </div>

        <div className="text-right text-xs text-muted-foreground">
          <p>
            {new Date(timeInfo.minISO).toLocaleString("es-CO", {
              month: "short",
              day: "numeric",
              hour: "2-digit",
              minute: "2-digit",
            })}{" "}
            →{" "}
            {new Date(timeInfo.maxISO).toLocaleString("es-CO", {
              month: "short",
              day: "numeric",
              hour: "2-digit",
              minute: "2-digit",
            })}
          </p>
          <p className="font-medium">{timeInfo.totalMinutes} min de datos</p>
        </div>
      </CardContent>
    </Card>
  )
}
