"use client"

import { useMemo } from "react"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  ScatterChart,
  Scatter,
  Cell,
  ReferenceLine,
} from "recharts"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import type { DataRow } from "@/lib/types"

interface ChartsProps {
  data: DataRow[]
  dateRange: [string, string] | null
}

function formatTime(iso: string) {
  const d = new Date(iso)
  return d.toLocaleTimeString("es-CO", { hour: "2-digit", minute: "2-digit" })
}

function formatDateTime(iso: string) {
  const d = new Date(iso)
  return d.toLocaleString("es-CO", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })
}

const RAPPI_ORANGE = "hsl(14, 100%, 50%)"
const RAPPI_GREEN = "hsl(160, 55%, 42%)"
const RAPPI_BLUE = "hsl(220, 65%, 50%)"
const RAPPI_AMBER = "hsl(40, 90%, 55%)"

// Custom tooltip component
function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number }>; label?: string }) {
  if (!active || !payload?.length) return null
  return (
    <div className="rounded-lg border border-border bg-card px-4 py-3 shadow-lg">
      <p className="mb-1 text-xs text-muted-foreground">{label}</p>
      <p className="text-lg font-bold text-foreground">
        {payload[0].value.toLocaleString()} tiendas
      </p>
    </div>
  )
}

// Downsample data to prevent rendering too many points
function downsample(data: Array<{ time: string; value: number; iso: string }>, maxPoints: number) {
  if (data.length <= maxPoints) return data
  const step = Math.ceil(data.length / maxPoints)
  return data.filter((_, i) => i % step === 0)
}

export function TimeSeriesChart({ data, dateRange }: ChartsProps) {
  const chartData = useMemo(() => {
    let filtered = data
    if (dateRange) {
      const [start, end] = dateRange
      filtered = data.filter((d) => d.timestamp >= start && d.timestamp <= end)
    }
    const mapped = filtered.map((d) => ({
      time: formatDateTime(d.timestamp),
      value: d.value,
      iso: d.timestamp,
    }))
    return downsample(mapped, 200)
  }, [data, dateRange])

  const avg = chartData.length > 0 ? chartData.reduce((s, d) => s + d.value, 0) / chartData.length : 0

  return (
    <Card className="border-0 shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-bold text-foreground">
          Tiendas Visibles en el Tiempo
        </CardTitle>
        <CardDescription>
          Serie temporal de tiendas disponibles con promedio
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={350}>
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="colorStores" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={RAPPI_ORANGE} stopOpacity={0.3} />
                <stop offset="95%" stopColor={RAPPI_ORANGE} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(30, 15%, 88%)" />
            <XAxis
              dataKey="time"
              tick={{ fontSize: 11, fill: "hsl(0, 0%, 40%)" }}
              tickLine={false}
              axisLine={false}
              interval="preserveStartEnd"
            />
            <YAxis
              tick={{ fontSize: 11, fill: "hsl(0, 0%, 40%)" }}
              tickLine={false}
              axisLine={false}
              tickFormatter={(v) => (v / 1000).toFixed(0) + "k"}
            />
            <Tooltip content={<CustomTooltip />} />
            <ReferenceLine
              y={avg}
              stroke={RAPPI_GREEN}
              strokeDasharray="5 5"
              label={{ value: "Promedio", position: "right", fontSize: 11, fill: RAPPI_GREEN }}
            />
            <Area
              type="monotone"
              dataKey="value"
              stroke={RAPPI_ORANGE}
              strokeWidth={2}
              fill="url(#colorStores)"
              dot={false}
              animationDuration={800}
            />
          </AreaChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

export function HourlyDistributionChart({ data, dateRange }: ChartsProps) {
  const chartData = useMemo(() => {
    let filtered = data
    if (dateRange) {
      const [start, end] = dateRange
      filtered = data.filter((d) => d.timestamp >= start && d.timestamp <= end)
    }
    const hourMap: Record<number, { total: number; count: number }> = {}
    filtered.forEach((d) => {
      const h = new Date(d.timestamp).getHours()
      if (!hourMap[h]) hourMap[h] = { total: 0, count: 0 }
      hourMap[h].total += d.value
      hourMap[h].count++
    })
    return Array.from({ length: 24 }, (_, i) => ({
      hour: `${i.toString().padStart(2, "0")}:00`,
      avg: hourMap[i] ? Math.round(hourMap[i].total / hourMap[i].count) : 0,
    }))
  }, [data, dateRange])

  return (
    <Card className="border-0 shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-bold text-foreground">
          Distribucion por Hora
        </CardTitle>
        <CardDescription>Promedio de tiendas visibles por hora del dia</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(30, 15%, 88%)" />
            <XAxis
              dataKey="hour"
              tick={{ fontSize: 11, fill: "hsl(0, 0%, 40%)" }}
              tickLine={false}
              axisLine={false}
            />
            <YAxis
              tick={{ fontSize: 11, fill: "hsl(0, 0%, 40%)" }}
              tickLine={false}
              axisLine={false}
              tickFormatter={(v) => (v / 1000).toFixed(0) + "k"}
            />
            <Tooltip
              formatter={(v: number) => [v.toLocaleString() + " tiendas", "Promedio"]}
              contentStyle={{
                borderRadius: "8px",
                border: "1px solid hsl(30, 15%, 88%)",
                boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
              }}
            />
            <Bar dataKey="avg" radius={[6, 6, 0, 0]} animationDuration={800}>
              {chartData.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={entry.avg > 25000 ? RAPPI_ORANGE : entry.avg > 20000 ? RAPPI_AMBER : RAPPI_BLUE}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

export function VolatilityChart({ data, dateRange }: ChartsProps) {
  const chartData = useMemo(() => {
    let filtered = data
    if (dateRange) {
      const [start, end] = dateRange
      filtered = data.filter((d) => d.timestamp >= start && d.timestamp <= end)
    }

    const result: Array<{ time: string; change: number; iso: string }> = []
    for (let i = 1; i < filtered.length; i++) {
      const change = filtered[i].value - filtered[i - 1].value
      result.push({
        time: formatTime(filtered[i].timestamp),
        change,
        iso: filtered[i].timestamp,
      })
    }
    return downsample(result, 200)
  }, [data, dateRange])

  return (
    <Card className="border-0 shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-bold text-foreground">
          Cambios entre Lecturas
        </CardTitle>
        <CardDescription>
          Variacion del numero de tiendas entre lecturas consecutivas
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(30, 15%, 88%)" />
            <XAxis
              dataKey="time"
              tick={{ fontSize: 11, fill: "hsl(0, 0%, 40%)" }}
              tickLine={false}
              axisLine={false}
              interval="preserveStartEnd"
            />
            <YAxis
              tick={{ fontSize: 11, fill: "hsl(0, 0%, 40%)" }}
              tickLine={false}
              axisLine={false}
            />
            <Tooltip
              formatter={(v: number) => [
                (v > 0 ? "+" : "") + v.toLocaleString() + " tiendas",
                "Cambio",
              ]}
              contentStyle={{
                borderRadius: "8px",
                border: "1px solid hsl(30, 15%, 88%)",
                boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
              }}
            />
            <ReferenceLine y={0} stroke="hsl(0, 0%, 60%)" />
            <Bar dataKey="change" radius={[4, 4, 0, 0]} animationDuration={600}>
              {chartData.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={entry.change >= 0 ? RAPPI_GREEN : "hsl(0, 75%, 55%)"}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

export function MovingAverageChart({ data, dateRange }: ChartsProps) {
  const chartData = useMemo(() => {
    let filtered = data
    if (dateRange) {
      const [start, end] = dateRange
      filtered = data.filter((d) => d.timestamp >= start && d.timestamp <= end)
    }

    const windowSize = Math.max(5, Math.floor(filtered.length / 50))
    const result: Array<{ time: string; value: number; ma: number }> = []

    for (let i = 0; i < filtered.length; i++) {
      const windowStart = Math.max(0, i - windowSize + 1)
      const window = filtered.slice(windowStart, i + 1)
      const ma = window.reduce((s, d) => s + d.value, 0) / window.length

      result.push({
        time: formatDateTime(filtered[i].timestamp),
        value: filtered[i].value,
        ma: Math.round(ma),
      })
    }

    return downsample(result, 200)
  }, [data, dateRange])

  return (
    <Card className="border-0 shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-bold text-foreground">
          Tendencia con Media Movil
        </CardTitle>
        <CardDescription>
          Valor real vs media movil suavizada
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(30, 15%, 88%)" />
            <XAxis
              dataKey="time"
              tick={{ fontSize: 11, fill: "hsl(0, 0%, 40%)" }}
              tickLine={false}
              axisLine={false}
              interval="preserveStartEnd"
            />
            <YAxis
              tick={{ fontSize: 11, fill: "hsl(0, 0%, 40%)" }}
              tickLine={false}
              axisLine={false}
              tickFormatter={(v) => (v / 1000).toFixed(0) + "k"}
            />
            <Tooltip
              formatter={(v: number, name: string) => [
                v.toLocaleString() + " tiendas",
                name === "value" ? "Real" : "Media Movil",
              ]}
              contentStyle={{
                borderRadius: "8px",
                border: "1px solid hsl(30, 15%, 88%)",
                boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
              }}
            />
            <Line
              type="monotone"
              dataKey="value"
              stroke="hsl(30, 15%, 80%)"
              strokeWidth={1}
              dot={false}
              name="value"
            />
            <Line
              type="monotone"
              dataKey="ma"
              stroke={RAPPI_ORANGE}
              strokeWidth={2.5}
              dot={false}
              name="ma"
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

export function ScatterDistribution({ data, dateRange }: ChartsProps) {
  const chartData = useMemo(() => {
    let filtered = data
    if (dateRange) {
      const [start, end] = dateRange
      filtered = data.filter((d) => d.timestamp >= start && d.timestamp <= end)
    }

    const mapped = filtered.map((d) => ({
      hour: new Date(d.timestamp).getHours() + new Date(d.timestamp).getMinutes() / 60,
      value: d.value,
    }))

    // Downsample for scatter
    if (mapped.length > 300) {
      const step = Math.ceil(mapped.length / 300)
      return mapped.filter((_, i) => i % step === 0)
    }
    return mapped
  }, [data, dateRange])

  return (
    <Card className="border-0 shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-bold text-foreground">
          Dispersion Hora vs Tiendas
        </CardTitle>
        <CardDescription>Relacion entre hora del dia y cantidad de tiendas</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <ScatterChart>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(30, 15%, 88%)" />
            <XAxis
              dataKey="hour"
              name="Hora"
              type="number"
              domain={[0, 24]}
              tick={{ fontSize: 11, fill: "hsl(0, 0%, 40%)" }}
              tickLine={false}
              axisLine={false}
              tickFormatter={(v) => `${Math.floor(v)}:00`}
            />
            <YAxis
              dataKey="value"
              name="Tiendas"
              tick={{ fontSize: 11, fill: "hsl(0, 0%, 40%)" }}
              tickLine={false}
              axisLine={false}
              tickFormatter={(v) => (v / 1000).toFixed(0) + "k"}
            />
            <Tooltip
              formatter={(v: number, name: string) => [
                name === "Hora"
                  ? `${Math.floor(v)}:${String(Math.round((v % 1) * 60)).padStart(2, "0")}`
                  : v.toLocaleString(),
                name,
              ]}
              contentStyle={{
                borderRadius: "8px",
                border: "1px solid hsl(30, 15%, 88%)",
                boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
              }}
            />
            <Scatter data={chartData} fill={RAPPI_ORANGE} fillOpacity={0.6} r={3} />
          </ScatterChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

export function MinMaxRangeChart({ data, dateRange }: ChartsProps) {
  const chartData = useMemo(() => {
    let filtered = data
    if (dateRange) {
      const [start, end] = dateRange
      filtered = data.filter((d) => d.timestamp >= start && d.timestamp <= end)
    }

    // Group by 5-minute intervals
    const intervalMap: Record<string, { min: number; max: number; avg: number; count: number }> = {}
    filtered.forEach((d) => {
      const date = new Date(d.timestamp)
      const key = `${date.getMonth() + 1}/${date.getDate()} ${date.getHours()}:${String(Math.floor(date.getMinutes() / 5) * 5).padStart(2, "0")}`
      if (!intervalMap[key]) {
        intervalMap[key] = { min: d.value, max: d.value, avg: d.value, count: 1 }
      } else {
        intervalMap[key].min = Math.min(intervalMap[key].min, d.value)
        intervalMap[key].max = Math.max(intervalMap[key].max, d.value)
        intervalMap[key].avg += d.value
        intervalMap[key].count++
      }
    })

    const entries = Object.entries(intervalMap).map(([time, v]) => ({
      time,
      min: v.min,
      max: v.max,
      avg: Math.round(v.avg / v.count),
      range: v.max - v.min,
    }))

    // Downsample
    if (entries.length > 100) {
      const step = Math.ceil(entries.length / 100)
      return entries.filter((_, i) => i % step === 0)
    }
    return entries
  }, [data, dateRange])

  return (
    <Card className="border-0 shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-bold text-foreground">
          Rango Min/Max por Intervalo
        </CardTitle>
        <CardDescription>Rango de variacion en intervalos de 5 minutos</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(30, 15%, 88%)" />
            <XAxis
              dataKey="time"
              tick={{ fontSize: 11, fill: "hsl(0, 0%, 40%)" }}
              tickLine={false}
              axisLine={false}
              interval="preserveStartEnd"
            />
            <YAxis
              tick={{ fontSize: 11, fill: "hsl(0, 0%, 40%)" }}
              tickLine={false}
              axisLine={false}
            />
            <Tooltip
              formatter={(v: number, name: string) => [
                v.toLocaleString(),
                name === "range" ? "Rango" : name,
              ]}
              contentStyle={{
                borderRadius: "8px",
                border: "1px solid hsl(30, 15%, 88%)",
                boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
              }}
            />
            <Bar dataKey="range" fill={RAPPI_BLUE} radius={[6, 6, 0, 0]} fillOpacity={0.8} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}
