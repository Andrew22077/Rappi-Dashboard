"use client"

import { useState, useMemo } from "react"
import { ChevronLeft, ChevronRight, ArrowUpDown } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { DataRow } from "@/lib/types"

interface DataTableProps {
  data: DataRow[]
  dateRange: [string, string] | null
}

const PAGE_SIZE = 15

export function DataTable({ data, dateRange }: DataTableProps) {
  const [page, setPage] = useState(0)
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc")
  const [sortKey, setSortKey] = useState<"timestamp" | "value">("timestamp")

  const filtered = useMemo(() => {
    let result = data
    if (dateRange) {
      const [start, end] = dateRange
      result = data.filter((d) => d.timestamp >= start && d.timestamp <= end)
    }
    result = [...result].sort((a, b) => {
      const aVal = sortKey === "timestamp" ? new Date(a.timestamp).getTime() : a.value
      const bVal = sortKey === "timestamp" ? new Date(b.timestamp).getTime() : b.value
      return sortDir === "asc" ? aVal - bVal : bVal - aVal
    })
    return result
  }, [data, dateRange, sortKey, sortDir])

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE)
  const pageData = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE)

  const toggleSort = (key: "timestamp" | "value") => {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"))
    } else {
      setSortKey(key)
      setSortDir("asc")
    }
    setPage(0)
  }

  return (
    <Card className="border-0 shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-bold text-foreground">
          Registros de Datos
        </CardTitle>
        <CardDescription>
          {filtered.length.toLocaleString()} registros{" "}
          {dateRange ? "(filtrados)" : "(total)"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto rounded-lg border border-border">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-secondary">
                <th className="px-4 py-3 text-left font-semibold text-foreground">Plot</th>
                <th className="px-4 py-3 text-left font-semibold text-foreground">Metrica</th>
                <th className="px-4 py-3 text-left font-semibold text-foreground">
                  <button
                    onClick={() => toggleSort("timestamp")}
                    className="flex items-center gap-1 hover:text-primary"
                  >
                    Timestamp
                    <ArrowUpDown className="h-3.5 w-3.5" />
                  </button>
                </th>
                <th className="px-4 py-3 text-right font-semibold text-foreground">
                  <button
                    onClick={() => toggleSort("value")}
                    className="ml-auto flex items-center gap-1 hover:text-primary"
                  >
                    Valor
                    <ArrowUpDown className="h-3.5 w-3.5" />
                  </button>
                </th>
              </tr>
            </thead>
            <tbody>
              {pageData.map((row, i) => (
                <tr
                  key={`${row.timestamp}-${i}`}
                  className="border-b border-border transition-colors last:border-0 hover:bg-accent/50"
                >
                  <td className="px-4 py-2.5 text-muted-foreground">{row.plotName}</td>
                  <td className="px-4 py-2.5">
                    <span className="rounded-full bg-accent px-2 py-0.5 text-xs font-medium text-accent-foreground">
                      {row.metric.replace("synthetic_monitoring_", "")}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-muted-foreground">
                    {new Date(row.timestamp).toLocaleString("es-CO", {
                      month: "short",
                      day: "numeric",
                      hour: "2-digit",
                      minute: "2-digit",
                      second: "2-digit",
                    })}
                  </td>
                  <td className="px-4 py-2.5 text-right font-semibold tabular-nums text-foreground">
                    {row.value.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-4 flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Pagina {page + 1} de {totalPages}
          </p>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              disabled={page === 0}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
              disabled={page >= totalPages - 1}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
