"use client"

import { useMemo } from "react"
import { Store } from "lucide-react"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { StatsCards } from "@/components/stats-cards"
import { DateFilter } from "@/components/date-filter"
import {
  TimeSeriesChart,
  HourlyDistributionChart,
  VolatilityChart,
  MovingAverageChart,
  ScatterDistribution,
  MinMaxRangeChart,
} from "@/components/charts"
import { DataTable } from "@/components/data-table"
import { Chatbot } from "@/components/chatbot"
import type { DataRow, StatsData } from "@/lib/types"

interface DashboardProps {
  data: DataRow[]
  dateRange: [string, string] | null
  onDateRangeChange: (range: [string, string] | null) => void
  onReset: () => void
}

export function Dashboard({ data, dateRange, onDateRangeChange, onReset }: DashboardProps) {
  const filteredData = useMemo(() => {
    if (!dateRange) return data
    const [start, end] = dateRange
    return data.filter((d) => d.timestamp >= start && d.timestamp <= end)
  }, [data, dateRange])

  const stats: StatsData = useMemo(() => {
    const values = filteredData.map((d) => d.value)
    const max = Math.max(...values)
    const min = Math.min(...values)
    const avg = Math.round(values.reduce((s, v) => s + v, 0) / values.length)
    const maxIdx = values.indexOf(max)
    const minIdx = values.indexOf(min)

    const timestamps = filteredData.map((d) => new Date(d.timestamp).getTime())
    const minTime = Math.min(...timestamps)
    const maxTime = Math.max(...timestamps)
    const diffMs = maxTime - minTime
    const diffMin = Math.round(diffMs / 60000)
    const hours = Math.floor(diffMin / 60)
    const mins = diffMin % 60
    const timeRange = hours > 0 ? `${hours}h ${mins}m` : `${mins} minutos`

    const volatility = ((max - min) / avg) * 100

    return {
      maxStores: max,
      minStores: min,
      avgStores: avg,
      maxTimestamp: filteredData[maxIdx]?.timestamp || "",
      minTimestamp: filteredData[minIdx]?.timestamp || "",
      totalRecords: filteredData.length,
      timeRange,
      volatility,
    }
  }, [filteredData])

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border bg-card/80 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary">
              <Store className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">
                Rappi Store Monitor
              </h1>
              <p className="text-xs text-muted-foreground">
                Dashboard de Disponibilidad de Tiendas
              </p>
            </div>
          </div>
          <button
            onClick={onReset}
            className="rounded-lg px-4 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
          >
            Subir nuevos datos
          </button>
        </div>
      </header>

      {/* Content */}
      <main className="mx-auto max-w-7xl px-6 py-6">
        <div className="flex flex-col gap-6">
          {/* Stats */}
          <StatsCards stats={stats} />

          {/* Filters */}
          <DateFilter
            data={data}
            dateRange={dateRange}
            onDateRangeChange={onDateRangeChange}
          />

          {/* Charts in tabs */}
          <Tabs defaultValue="timeline" className="w-full">
            <TabsList className="mb-4 grid w-full grid-cols-3 lg:w-auto lg:inline-flex">
              <TabsTrigger value="timeline">Serie Temporal</TabsTrigger>
              <TabsTrigger value="analysis">Analisis</TabsTrigger>
              <TabsTrigger value="table">Datos</TabsTrigger>
            </TabsList>

            <TabsContent value="timeline" className="flex flex-col gap-6">
              <TimeSeriesChart data={data} dateRange={dateRange} />
              <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                <MovingAverageChart data={data} dateRange={dateRange} />
                <VolatilityChart data={data} dateRange={dateRange} />
              </div>
            </TabsContent>

            <TabsContent value="analysis" className="flex flex-col gap-6">
              <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                <HourlyDistributionChart data={data} dateRange={dateRange} />
                <ScatterDistribution data={data} dateRange={dateRange} />
              </div>
              <MinMaxRangeChart data={data} dateRange={dateRange} />
            </TabsContent>

            <TabsContent value="table">
              <DataTable data={data} dateRange={dateRange} />
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Chatbot */}
      <Chatbot data={data} stats={stats} />
    </div>
  )
}
