"use client"

import { useState, useCallback } from "react"
import { FileUpload } from "@/components/file-upload"
import { Dashboard } from "@/components/dashboard"
import type { DataRow } from "@/lib/types"

export default function Page() {
  const [data, setData] = useState<DataRow[] | null>(null)
  const [dateRange, setDateRange] = useState<[string, string] | null>(null)
  const [loading, setLoading] = useState(false)

  const loadData = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch("/api/process")
      const json = await res.json()
      if (json.data && json.data.length > 0) {
        setData(json.data)
      }
    } catch (err) {
      console.error("Error loading data:", err)
    } finally {
      setLoading(false)
    }
  }, [])

  const handleReset = () => {
    setData(null)
    setDateRange(null)
  }

  if (loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent" />
        <p className="text-lg font-medium text-foreground">Cargando datos...</p>
        <p className="text-sm text-muted-foreground">Procesando registros de disponibilidad</p>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-background">
        <FileUpload onUploadComplete={loadData} />
      </div>
    )
  }

  return (
    <Dashboard
      data={data}
      dateRange={dateRange}
      onDateRangeChange={setDateRange}
      onReset={handleReset}
    />
  )
}
