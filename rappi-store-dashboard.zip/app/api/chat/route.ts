import { streamText, convertToModelMessages, UIMessage, consumeStream } from "ai"

export const maxDuration = 30

export async function POST(req: Request) {
  const { messages, dataContext }: { messages: UIMessage[]; dataContext: string } = await req.json()

  const result = streamText({
    model: "openai/gpt-4o-mini",
    system: `Eres el asistente de datos de Rappi Store Monitor. Tu rol es analizar datos de disponibilidad de tiendas y responder preguntas de forma clara, concisa y profesional en espanol.

CONTEXTO DE LOS DATOS:
${dataContext}

INSTRUCCIONES:
- Responde siempre en espanol
- Usa numeros formateados (ej: 1,234 en vez de 1234)
- Si te preguntan algo fuera de los datos, indica amablemente que solo puedes responder sobre los datos del dashboard
- Se preciso con los datos, no inventes numeros
- Usa formato markdown cuando sea util (negritas, listas, etc.)
- Se amigable y profesional, como un analista de datos de Rappi
- Si no tienes suficiente contexto para responder, pidele al usuario que sea mas especifico`,
    messages: await convertToModelMessages(messages),
    abortSignal: req.signal,
  })

  return result.toUIMessageStreamResponse({
    originalMessages: messages,
    consumeSseStream: consumeStream,
  })
}
