import { NextResponse } from "next/server"
import { promises as fs } from "fs"
import path from "path"

const UPLOAD_DIR = path.join(process.cwd(), "uploads")

interface DataRow {
  plotName: string
  metric: string
  timestamp: string
  value: number
}

function parseCSVLine(line: string): string[] {
  const result: string[] = []
  let current = ""
  let inQuotes = false
  for (let i = 0; i < line.length; i++) {
    if (line[i] === '"') {
      inQuotes = !inQuotes
    } else if (line[i] === "," && !inQuotes) {
      result.push(current.trim())
      current = ""
    } else {
      current += line[i]
    }
  }
  result.push(current.trim())
  return result
}

function parseTimestamp(raw: string): string {
  // Handle format like "Sun Feb 01 2026 06:59:40 GMT-0500 (hora estándar de Colombia)"
  try {
    const cleaned = raw.replace(/\s*\(.*\)$/, "").trim()
    const d = new Date(cleaned)
    if (!isNaN(d.getTime())) {
      return d.toISOString()
    }
  } catch {
    // fall through
  }
  return raw
}

export async function GET() {
  try {
    await fs.mkdir(UPLOAD_DIR, { recursive: true })

    const dirFiles = await fs.readdir(UPLOAD_DIR)
    const csvFiles = dirFiles.filter((f) => f.endsWith(".csv"))

    if (csvFiles.length === 0) {
      return NextResponse.json({ data: [], files: 0 })
    }

    const allRows: DataRow[] = []

    for (const csvFile of csvFiles) {
      const filePath = path.join(UPLOAD_DIR, csvFile)
      const content = await fs.readFile(filePath, "utf-8")
      const lines = content.split("\n").filter((l) => l.trim().length > 0)

      if (lines.length < 2) continue

      const headers = parseCSVLine(lines[0])

      // Check format: could be already vertical (has timestamp/value columns)
      // or horizontal (timestamps as column headers)
      const hasTimestampCol = headers.some(
        (h) => h.toLowerCase() === "timestamp"
      )
      const hasValueCol = headers.some((h) => h.toLowerCase() === "value")

      if (hasTimestampCol && hasValueCol) {
        // Already in vertical/long format
        const tsIdx = headers.findIndex(
          (h) => h.toLowerCase() === "timestamp"
        )
        const valIdx = headers.findIndex((h) => h.toLowerCase() === "value")
        const plotIdx = headers.findIndex(
          (h) => h.toLowerCase().includes("plot")
        )
        const metricIdx = headers.findIndex(
          (h) => h.toLowerCase().includes("metric")
        )

        for (let i = 1; i < lines.length; i++) {
          const cols = parseCSVLine(lines[i])
          const val = parseFloat(cols[valIdx])
          if (isNaN(val)) continue

          allRows.push({
            plotName: plotIdx >= 0 ? cols[plotIdx] : "Unknown",
            metric: metricIdx >= 0 ? cols[metricIdx] : "unknown_metric",
            timestamp: parseTimestamp(cols[tsIdx]),
            value: val,
          })
        }
      } else {
        // Horizontal format: melt columns into rows
        // Columns: Plot name, metric (sf_metric), Value Prefix, Value Suffix, <timestamps...>
        const fixedCols = 4
        const timestamps = headers.slice(fixedCols)

        for (let i = 1; i < lines.length; i++) {
          const cols = parseCSVLine(lines[i])
          const plotName = cols[0] || "Unknown"
          const metric = cols[1] || "unknown_metric"

          for (let j = fixedCols; j < cols.length; j++) {
            const val = parseFloat(cols[j])
            if (isNaN(val)) continue
            allRows.push({
              plotName,
              metric,
              timestamp: parseTimestamp(timestamps[j - fixedCols] || ""),
              value: val,
            })
          }
        }
      }
    }

    // Sort by timestamp
    allRows.sort(
      (a, b) =>
        new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    )

    // Remove duplicates
    const seen = new Set<string>()
    const unique = allRows.filter((row) => {
      const key = `${row.plotName}-${row.metric}-${row.timestamp}-${row.value}`
      if (seen.has(key)) return false
      seen.add(key)
      return true
    })

    return NextResponse.json({
      data: unique,
      files: csvFiles.length,
      totalRows: unique.length,
    })
  } catch (error) {
    console.error("Process error:", error)
    return NextResponse.json({ error: "Processing failed" }, { status: 500 })
  }
}
